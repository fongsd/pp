#ifndef KVATERNION_HPP
#define KVATERNION_HPP

typedef struct {
	double s = 0, i = 0, j = 0, k = 0;
} kvaternion;

typedef struct {
	double vrednost;
	char oznaka;
} element_t;

#endif
